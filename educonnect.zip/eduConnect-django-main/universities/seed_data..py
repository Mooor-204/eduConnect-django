from .models import University, Faculty

def load_initial_data():
    data = [
        {
            "name": "جامعة القاهرة",
            "address": "الجيزة، بالقرب من كوبري الجامعة",
            "tuition_fees": "15,000 جنيه سنويًا (برامج متميزة)",
            "website": "https://cu.edu.eg",
            "description": "من أقدم وأعرق الجامعات في مصر والشرق الأوسط، تأسست عام 1908، وتضم أكثر من 25 كلية ومعهدًا.",
            "faculties": [
                {"name": "كلية الطب", "tuition_fees": "25,000 جنيه", "years": 7, "description": "من أكبر كليات الطب في مصر."},
                {"name": "كلية الهندسة", "tuition_fees": "20,000 جنيه", "years": 5, "description": "تضم تخصصات الكهرباء والميكانيكا والعمارة."},
                {"name": "كلية التجارة", "tuition_fees": "10,000 جنيه", "years": 4, "description": "من أكثر الكليات إقبالًا وتضم المحاسبة والإدارة."},
            ]
        },
        {
            "name": "جامعة عين شمس",
            "address": "العباسية، القاهرة",
            "tuition_fees": "10,000 جنيه سنويًا (برامج متميزة)",
            "website": "https://www.asu.edu.eg",
            "description": "تأسست عام 1950 وتعد من الجامعات الحكومية الرائدة في مصر في مجالات العلوم والطب والهندسة.",
            "faculties": [
                {"name": "كلية الحاسبات والمعلومات", "tuition_fees": "18,000 جنيه", "years": 4, "description": "تدرس البرمجة والذكاء الاصطناعي."},
                {"name": "كلية الطب", "tuition_fees": "27,000 جنيه", "years": 7, "description": "من أفضل كليات الطب في مصر."},
                {"name": "كلية الحقوق", "tuition_fees": "10,000 جنيه", "years": 4, "description": "تدرس القوانين المصرية والدولية."},
            ]
        },
        {
            "name": "جامعة الإسكندرية",
            "address": "الشاطبي، الإسكندرية",
            "tuition_fees": "12,000 جنيه سنويًا (برامج خاصة)",
            "website": "https://alexu.edu.eg",
            "description": "تأسست عام 1942 وتعتبر من أبرز الجامعات الإقليمية، خاصة في المجالات العلمية والطبية.",
            "faculties": [
                {"name": "كلية الزراعة", "tuition_fees": "8,000 جنيه", "years": 4, "description": "من أقدم كليات الزراعة في مصر."},
                {"name": "كلية الصيدلة", "tuition_fees": "23,000 جنيه", "years": 5, "description": "تخرّج صيادلة متميزين في التصنيع الدوائي."},
                {"name": "كلية العلوم", "tuition_fees": "12,000 جنيه", "years": 4, "description": "تشمل تخصصات الكيمياء والفيزياء والبيولوجي."},
            ]
        },
        {
            "name": "جامعة النيل الأهلية",
            "address": "الشيخ زايد، الجيزة",
            "tuition_fees": "بين 50,000 و 80,000 جنيه سنويًا",
            "website": "https://nu.edu.eg",
            "description": "جامعة أهلية غير هادفة للربح تركز على البحث العلمي والتكنولوجيا وريادة الأعمال.",
            "faculties": [
                {"name": "كلية تكنولوجيا المعلومات", "tuition_fees": "60,000 جنيه", "years": 4, "description": "تدرس علوم البرمجة وتحليل البيانات."},
                {"name": "كلية إدارة الأعمال", "tuition_fees": "55,000 جنيه", "years": 4, "description": "تدرس ريادة الأعمال والإدارة الحديثة."},
                {"name": "كلية الهندسة", "tuition_fees": "70,000 جنيه", "years": 5, "description": "تهتم بالهندسة الصناعية والميكاترونكس."},
            ]
        },
        {
            "name": "جامعة المستقبل",
            "address": "التجمع الخامس، القاهرة الجديدة",
            "tuition_fees": "من 60,000 إلى 90,000 جنيه سنويًا",
            "website": "https://www.fue.edu.eg",
            "description": "جامعة خاصة حديثة تقدم تعليمًا عالميًا في مجالات الطب والهندسة والإدارة.",
            "faculties": [
                {"name": "كلية طب الفم والأسنان", "tuition_fees": "80,000 جنيه", "years": 5, "description": "من أبرز كليات الأسنان الخاصة في مصر."},
                {"name": "كلية الصيدلة", "tuition_fees": "75,000 جنيه", "years": 5, "description": "تجهّز خريجين مؤهلين للعمل في الشركات الدوائية."},
                {"name": "كلية الاقتصاد والعلوم السياسية", "tuition_fees": "60,000 جنيه", "years": 4, "description": "تهتم بدراسة العلاقات الدولية والسياسات العامة."},
            ]
        }
    ]

    for uni_data in data:
        university = University.objects.create(
            name=uni_data["name"],
            address=uni_data["address"],
            tuition_fees=uni_data["tuition_fees"],
            website=uni_data["website"],
            description=uni_data["description"]
        )
        for f in uni_data["faculties"]:
            Faculty.objects.create(
                university=university,
                name=f["name"],
                tuition_fees=f["tuition_fees"],
                years=f["years"],
                description=f["description"]
            )
