from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import University, Faculty

admin.site.register(University)
admin.site.register(Faculty)

