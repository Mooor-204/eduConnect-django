from django.shortcuts import get_object_or_404, render
from .models import University

def universities_list(request):
    universities = University.objects.all()
    return render(request, 'universities/universities_list.html', {'universities': universities})

def university_detail(request, pk):
    university = get_object_or_404(University, pk=pk)
    return render(request, 'universities/university_detail.html', {'university': university})
